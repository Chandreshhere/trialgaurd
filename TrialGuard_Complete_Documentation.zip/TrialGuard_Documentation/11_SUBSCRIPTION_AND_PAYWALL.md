# Subscription, Pricing & Entitlements

## Pricing Strategy for Initial Test

### Free
- up to 3 active protected trials;
- manual entry;
- basic reminders;
- limited screenshot AI scans per month or trial period.

### Pro — Test Variant A
- $19.99/year

### Pro — Test Variant B
- $24.99/year

### Optional Lifetime Test
- $29.99–49.99 one-time, only if unit economics support it.

Do not finalize pricing without A/B testing and store-economics review.

## Pro Entitlements
- unlimited active trials;
- AI screenshot import;
- advanced/aggressive reminders;
- cancellation proof storage;
- advanced reminder customization;
- full Money Saved history;
- priority provider guides.

## Paywall Principles
1. User should understand value before paywall.
2. Prefer contextual paywall after user successfully protects at least one trial.
3. Avoid fake countdowns.
4. Clearly show billing period and renewal.
5. Include restore purchase.
6. Make cancellation/manage-subscription pathway easy to find.

## TrialGuard's Own Renewal Ethics
Recommended trust differentiator:
- send a clear renewal reminder for TrialGuard itself;
- make manage/cancel subscription accessible from Profile;
- avoid manipulative retention steps.

## RevenueCat
Use RevenueCat as entitlement abstraction layer.

Recommended entitlement:
`pro`

Suggested product IDs:
- `trialguard_pro_annual`
- `trialguard_lifetime` if used.

## Entitlement State
App must handle:
- active;
- grace period;
- billing retry;
- expired;
- revoked/refunded;
- lifetime.

## Free Limit Behavior
If user exceeds free active trial limit:
- existing active trials remain visible and reminders continue;
- block adding additional protected trials until upgrade or old trial resolved;
- never disable an already-scheduled critical reminder just because entitlement changed.

## Restore Purchases
Mandatory accessible action from Paywall and Settings.
