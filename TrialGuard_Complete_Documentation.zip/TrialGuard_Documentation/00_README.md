# TrialGuard Documentation Pack

## Product
**TrialGuard** — a mobile-first app that helps users avoid accidental charges from forgotten free trials.

## Core Promise
> Screenshot your free trial. TrialGuard extracts the renewal details, reminds you before the charge, guides you to cancel, and stores proof that you cancelled.

## Primary Product Principle
TrialGuard is **not** a budgeting app, bank-connected subscription manager, or general finance tracker. The first version focuses only on one narrow problem:

> **I started a free trial and do not want to forget when it becomes paid.**

## Documentation Index

1. `01_PRD.md` — Product Requirements Document
2. `02_SRS.md` — Software Requirements Specification
3. `03_USER_PERSONAS_AND_JOBS.md` — target users, JTBD, pain points
4. `04_USER_FLOWS.md` — end-to-end user journeys
5. `05_SCREENS.md` — complete screen inventory and UI behavior
6. `06_DESIGN_SYSTEM.md` — UX/UI direction and component rules
7. `07_DATA_MODEL.md` — entities, tables, enums, relationships
8. `08_API_AND_BACKEND.md` — backend modules and API contracts
9. `09_AI_EXTRACTION_SPEC.md` — screenshot/text extraction rules
10. `10_NOTIFICATION_ENGINE.md` — reminder scheduling and urgency logic
11. `11_SUBSCRIPTION_AND_PAYWALL.md` — pricing, entitlements, billing behavior
12. `12_ANALYTICS_AND_EVENTS.md` — event taxonomy and metrics
13. `13_SECURITY_PRIVACY_COMPLIANCE.md` — security/privacy requirements
14. `14_QA_TEST_PLAN.md` — functional, edge-case, device, and regression testing
15. `15_RELEASE_AND_ROADMAP.md` — MVP scope, later phases, launch gates
16. `16_CONTENT_AND_COPY.md` — default product copy and notification copy
17. `17_TECH_STACK_AND_REPO.md` — recommended architecture and project structure
18. `18_ACCEPTANCE_CRITERIA.md` — release-level acceptance criteria

## Recommended MVP Technology

- **Mobile:** React Native + Expo + TypeScript
- **State/data fetching:** TanStack Query + lightweight local state store
- **Backend:** Supabase
- **Database:** PostgreSQL
- **Auth:** Supabase Auth
- **Storage:** Supabase Storage initially
- **Push notifications:** Expo Notifications/APNs/FCM
- **AI extraction:** multimodal LLM or OCR + structured extraction pipeline
- **Subscriptions:** RevenueCat + Apple App Store + Google Play
- **Analytics:** PostHog, Amplitude, Mixpanel, or equivalent
- **Crash/error reporting:** Sentry

## MVP North-Star Experience

1. User imports a screenshot of a free-trial confirmation.
2. TrialGuard identifies service name, trial end date, renewal amount, currency, and billing period.
3. User confirms/corrects the detected fields.
4. TrialGuard activates protection and schedules multiple reminders.
5. Before billing, the user chooses **Keep** or **Cancel**.
6. If cancelling, TrialGuard opens the cancellation path/instructions.
7. User optionally uploads confirmation proof.
8. TrialGuard marks the trial as cancelled and adds the avoided renewal amount to **Money Saved**.

## MVP Non-Goals

Do not add these to v1 unless scope is formally changed:

- Bank-account linking
- Automatic transaction detection
- Credit-score tools
- Budgeting
- Expense tracking
- Investment/crypto features
- Automatic cancellation via credential collection
- VPN/ad-blocking/scam detection
- Marketplace/service-provider connections
- Browser extension
- Email inbox integration
- Family sharing
- Desktop/web dashboard

## Product Success Definition

TrialGuard is successful when users can protect a new trial in under **30 seconds**, receive trustworthy reminders, and confidently avoid an accidental renewal without needing any financial-account integration.
