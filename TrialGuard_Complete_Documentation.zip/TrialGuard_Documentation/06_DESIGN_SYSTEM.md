# Design System & UX Direction

## Brand Character
TrialGuard should feel:
- protective;
- calm;
- trustworthy;
- direct;
- consumer-friendly;
- financially aware without looking like a banking app.

Avoid:
- crypto/fintech aesthetics;
- aggressive fear-mongering;
- excessive red;
- dark patterns;
- cluttered dashboards.

## Core Visual Metaphor
**Shield / Protection**

Use sparingly in:
- protected state;
- trial protection activation;
- active shield dashboard.

## Information Hierarchy
The most important data is always:
1. amount at risk;
2. time until renewal/safe-cancel deadline;
3. provider;
4. current decision/status.

## Typography
Use a modern sans-serif with excellent mobile readability.

Recommended type scale:
- Display: 32–40
- H1: 28–32
- H2: 22–24
- H3: 18–20
- Body: 16
- Small: 13–14

## Spacing
Use 4/8-point spacing system.

## Touch Targets
Minimum 44x44pt equivalent.

## Cards
Active trial card must show:
- provider;
- amount;
- countdown;
- urgency;
- status.

Do not hide amount behind a details view.

## Urgency States
Recommended semantic levels:
- Safe: > 7 days
- Upcoming: 3–7 days
- Urgent: 24–72 hours
- Critical: < 24 hours

Do not rely on color alone; include icon/text.

## Motion
Use subtle motion for:
- Shield activation;
- successful cancellation;
- dashboard metric transitions.

Avoid confetti for financial-risk events unless testing proves appropriate.

## Accessibility
- dynamic text support;
- semantic labels;
- screen reader descriptions for countdowns;
- high contrast;
- reduce-motion support;
- never encode urgency only by color.

## Copy Style
Short, concrete, money-aware.

Prefer:
`Adobe may charge $79.99 tomorrow.`

Avoid:
`Your Adobe subscription renewal event is approaching.`

## Trust UX
- show original extracted screenshot in detail view;
- show editable detected fields;
- state when date/time is uncertain;
- make cancel links transparent;
- make TrialGuard's own subscription cancellation easy to find.
