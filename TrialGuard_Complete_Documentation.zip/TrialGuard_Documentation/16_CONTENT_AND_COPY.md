# Product Content & Copy Library

## Positioning
### Primary
**Never pay for a trial you forgot.**

### Supporting
**Screenshot your free trial. TrialGuard reminds you before it becomes paid.**

## Onboarding

### Screen 1
**Never pay for a trial you forgot.**

Free trials are easy to start and surprisingly easy to forget.

CTA: `Get Started`

### Screen 2
**Protect it in seconds.**

Import a screenshot. We detect the renewal date and amount. You confirm the details.

### Screen 3
**We keep asking before they charge.**

Get reminders before the renewal so you can keep it or cancel it on purpose.

## Add Trial
### Empty dashboard
**Nothing at risk right now.**

Protect your next free trial before you forget it.

CTA: `Protect a Trial`

### Source method
**How do you want to add it?**

Recommended: `Import Screenshot`

## AI Processing
**Finding the renewal date and charge…**

Fallback:
`We couldn't read everything clearly. You can fill in the missing details.`

## Review
**Check this before we protect it.**

Helper:
`TrialGuard never relies on AI alone for billing dates.`

## Success
**$79.99 protected ✓**

`We’ll remind you before Adobe is expected to renew.`

## Dashboard
### Metric
**Money at risk**

Helper:
`Upcoming charges from active trials.`

### Saved metric
**Money you saved**

Helper:
`Renewals you marked cancelled before billing.`

## Decision Screen
**Adobe may charge $79.99 in 3 days.**

`Do you still want it?`

Buttons:
- `Cancel It`
- `Keep It`
- `Decide Later`

## Cancel Flow
**Cancel Adobe**

`We’ll take you to Adobe. Complete cancellation there, then come back and confirm it here.`

CTA: `Open Adobe`

Secondary: `I Cancelled It`

## Proof
**Save proof of cancellation?**

`Keep the confirmation screenshot with this trial in case you need it later.`

## Saved
**You avoided $79.99.**

`Nice. That trial is no longer set as an upcoming risk in TrialGuard.`

## Paywall
**Protect every trial.**

Pro includes:
- unlimited protected trials;
- screenshot detection;
- stronger reminder controls;
- cancellation proof;
- full saved-money history.

CTA example:
`Get Pro — $19.99/year`

## Notification Copy

### 7d
`Adobe may charge $79.99 next week.`
`Still want it?`

### 3d
`$79.99 at risk in 3 days.`
`Adobe is still set to renew.`

### 24h
`Adobe may charge $79.99 tomorrow.`
`Cancel now if you don't want it.`

### 6h
`Final TrialGuard reminder.`
`Adobe's $79.99 renewal is approaching.`

## Errors
### No date detected
`We couldn't find a clear renewal date.`
`Add it manually so we don't guess.`

### Multiple prices
`We found more than one price.`
`Choose the amount you'll actually be charged.`

### Notifications disabled
**Reminders are off.**
`Your trial is saved, but TrialGuard can't alert you until notifications are enabled.`

### Offline
`You're offline.`
`Your saved trials are still available. Screenshot analysis will resume when you're connected.`
