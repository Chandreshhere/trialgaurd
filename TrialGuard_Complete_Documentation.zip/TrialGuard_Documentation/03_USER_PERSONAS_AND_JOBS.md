# User Personas, Jobs, Pain Points

## Persona 1 — The Trial Explorer
**Age:** 20–35

Frequently tests:
- AI tools;
- design software;
- streaming;
- productivity apps;
- education platforms;
- fitness apps.

### Pain
Starts trials impulsively, trusts memory, and occasionally gets charged.

### Desired Outcome
A five-second way to protect the trial immediately after signup.

---

## Persona 2 — The Cost-Conscious Professional
**Age:** 25–45

Has disposable income but dislikes waste. May intentionally try expensive annual products before deciding.

### Pain
A forgotten $80–$200 annual renewal feels avoidable and frustrating.

### Desired Outcome
Clear visibility into upcoming trial charges and easy cancellation paths.

---

## Persona 3 — The Forgetful / Overloaded User
Has many competing tasks and reminders.

### Pain
A normal calendar reminder is easy to dismiss, forget, or never create.

### Desired Outcome
Escalating reminders with strong monetary context.

---

## Persona 4 — The Subscription Skeptic
Avoids subscription-management apps that require bank or inbox access.

### Pain
Does not want to hand over financial credentials or email permissions.

### Desired Outcome
A privacy-light product that works from screenshots and manual input.

---

# Jobs To Be Done

## Functional Jobs
1. Capture trial renewal details quickly.
2. Know exactly when a charge is expected.
3. Remember in time.
4. Decide to keep or cancel.
5. Find the cancellation path.
6. Keep proof of cancellation.
7. Understand how much money was avoided.

## Emotional Jobs
1. Reduce anxiety about forgetting.
2. Feel in control of subscriptions.
3. Avoid the regret of an unnecessary charge.
4. Trust that the app is working for the user, not against them.

## Social Jobs
Low priority in MVP. Product should not require social interaction.

# Pain Severity Triggers

### High Pain
- renewal is annual;
- amount > $50;
- trial ends in < 72 hours;
- provider has difficult cancellation path;
- user has already been charged accidentally before.

### Medium Pain
- small monthly renewal;
- user still evaluating product;
- cancellation is straightforward.

# Anti-Personas
Do not optimize MVP for:
- enterprise procurement teams;
- businesses managing employee subscriptions;
- finance/accounting departments;
- people seeking full bank-level subscription detection;
- users expecting TrialGuard to cancel services automatically without action.
