# Product Requirements Document (PRD)

## 1. Product Name
TrialGuard

## 2. Product Vision
Create the simplest global consumer utility for preventing accidental charges caused by forgotten free trials.

## 3. Problem Statement
Consumers increasingly start free trials for software, streaming, AI tools, fitness, productivity, gaming, education, media, and other digital services. The user often intends to evaluate the service and cancel before billing, but forgets the exact renewal date or fails to create a reminder. A small lapse can cause an unwanted annual or monthly charge.

Existing approaches fail because they often require one or more of the following:

- manually creating a calendar event;
- manually entering subscription details;
- connecting a bank account;
- granting email access;
- using a large personal-finance application;
- remembering the trial exists before a charge occurs.

TrialGuard reduces setup friction by making the primary input a **screenshot, pasted text, camera capture, or manual form**.

## 4. Product Goal
Enable a user to go from a trial confirmation screenshot to a protected, reminder-backed trial record in less than 30 seconds.

## 5. Core Value Proposition
**Screenshot your free trial. We will make sure you decide before it charges.**

## 6. Target Platforms

### MVP
- iOS
- Android

### Later
- Browser extension
- Lightweight web account portal

## 7. Target Markets
Initial launch priority:

1. United States
2. Canada
3. United Kingdom
4. Australia
5. English-speaking users in Europe

## 8. Target User
A digitally active consumer who regularly tries apps/services and wants to avoid unintended renewals.

Typical characteristics:
- age 18–45;
- uses multiple digital subscriptions;
- comfortable installing apps;
- starts free trials at least several times per year;
- has previously forgotten a trial, fears forgetting one, or already creates manual reminders.

## 9. Jobs To Be Done

### Primary JTBD
When I start a free trial, I want to capture the renewal details immediately so I can decide whether to keep or cancel it before I am charged.

### Secondary JTBD
- Tell me how much money is currently at risk.
- Remind me more than once.
- Make the cancellation path easy to find.
- Let me prove I cancelled.
- Show how much money I have avoided spending.

## 10. Core MVP Features

### F1. User onboarding
- Introduce product promise.
- Explain notification requirement.
- Allow account creation or trial mode if product strategy permits.

### F2. Add trial
Input methods:
- screenshot/image import;
- camera capture;
- paste text;
- manual entry.

### F3. AI extraction
Extract:
- service/provider;
- plan name where available;
- trial start date if available;
- trial/renewal date;
- renewal amount;
- currency;
- billing period;
- cancellation deadline if explicitly stated.

### F4. Confirmation step
Never schedule reminders solely from AI output without user confirmation.

### F5. Trial Shield
- Save active trial.
- Create safe-cancel date.
- Schedule reminders.
- Show amount at risk.

### F6. Reminder ladder
Default reminder sequence:
- 7 days before;
- 3 days before;
- 24 hours before;
- 6 hours before.

System must adapt if trial is shorter than this sequence.

### F7. Keep or Cancel decision
User can:
- keep subscription;
- cancel subscription;
- snooze decision.

### F8. Cancellation assistant
- direct cancellation URL where known;
- concise step-by-step instructions;
- system-level deep link for Apple/Google subscriptions where applicable;
- no password collection in MVP.

### F9. Cancellation proof
- upload screenshot;
- record timestamp;
- optional confirmation/reference number;
- mark verified by user or extraction where appropriate.

### F10. Money saved
Calculate avoided renewal amount only when user confirms cancellation before renewal.

### F11. History
States:
- active;
- kept;
- cancelled;
- expired;
- charged/unknown;
- archived.

### F12. Paywall
Free vs Pro limits defined in subscription specification.

## 11. MVP User Promise Boundaries
TrialGuard must not promise:
- guaranteed cancellation;
- automatic cancellation for every provider;
- guaranteed prevention of charges;
- legal/refund guarantees;
- financial advice.

Suggested language:
> TrialGuard helps you track and act before renewal. Cancellation terms and billing rules are controlled by each service provider.

## 12. KPIs

### Activation
- % onboarding users who protect first trial.
- median time to first protected trial.
- screenshot import success rate.

### Engagement
- active trials/user;
- notification open rate;
- decision completion rate;
- return sessions caused by reminders.

### Value
- total declared money saved;
- % trials cancelled before renewal;
- % users who upload cancellation proof.

### Monetization
- free-to-paid conversion;
- annual vs lifetime split if lifetime is offered;
- trial-to-paid conversion for TrialGuard itself;
- churn/refund rate.

### Reliability
- AI date extraction accuracy;
- notification delivery/scheduling success;
- crash-free sessions;
- duplicate trial rate.

## 13. Product Principles
1. **Capture fast.** Setup must feel lighter than making a calendar reminder.
2. **Confirm critical data.** Dates and amounts are too important to trust blindly.
3. **Be visibly on the user's side.** No dark patterns.
4. **Escalate reminders.** One silent notification is insufficient.
5. **Avoid financial-account access in MVP.** Simplicity and trust are advantages.
6. **Make saved money visible.** Users should feel tangible ROI.
7. **Do not overbuild.** Trial protection is the product.
