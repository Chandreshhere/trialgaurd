# QA & Test Plan

## 1. Test Categories
- unit tests;
- integration tests;
- UI/E2E tests;
- notification tests;
- timezone/date tests;
- AI extraction tests;
- subscription tests;
- security/access tests;
- accessibility tests;
- device matrix tests;
- regression tests.

## 2. Critical Path Tests

### TC-001 Screenshot to Protected Trial
Given valid screenshot with service/date/amount,
when user imports and confirms,
then active trial is created and reminders scheduled.

### TC-002 Incorrect AI Date
Given wrong detected date,
when user edits it,
then corrected date is stored and reminders use corrected date.

### TC-003 Missing Amount
Given screenshot without amount,
system must allow unknown amount without hallucinating one.

### TC-004 Short Trial
Given renewal in 36 hours,
system must not schedule a 7-day reminder in the past.

### TC-005 Notification Permission Denied
User can create trial but UI clearly indicates reminders are disabled.

### TC-006 Cancelled Trial
When marked cancelled,
all future reminders are cancelled.

### TC-007 Kept Trial
When marked kept,
all cancellation reminders stop.

### TC-008 Edit Renewal Date
Changing date reschedules reminders and removes old schedule.

### TC-009 Duplicate Activation
Tapping activate twice must not create duplicate reminders.

### TC-010 Paywall Limit
Free user over limit cannot add new protected trial but existing trial protections remain active.

## 3. AI Extraction Test Dataset
Create anonymized test set covering:
- Apple trial receipts;
- Google Play trials;
- Adobe-like annual plans;
- monthly plans;
- 3-day/7-day/14-day/30-day trials;
- multiple prices in one screenshot;
- multiple dates;
- discounts;
- currencies USD/GBP/EUR/CAD/AUD;
- ambiguous MM/DD vs DD/MM;
- dark mode/light mode;
- low-resolution screenshots;
- cropped screenshots;
- screenshots with no trial information.

Measure per-field accuracy separately.

## 4. Date/Timezone Tests
Test:
- DST start/end;
- travel across timezones;
- date-only renewal;
- exact provider time;
- midnight renewals;
- leap day;
- year boundary;
- locale date formats.

## 5. Notification Tests
On physical iOS and Android devices:
- app foreground;
- app background;
- app killed;
- device restarted;
- timezone changed;
- notification permission toggled;
- battery saver modes where relevant.

## 6. Subscription Tests
Use Apple/Google sandbox:
- purchase success;
- purchase cancel;
- restore;
- renewal;
- expiry;
- refund/revoke;
- grace period;
- offline entitlement cache.

## 7. Security Tests
- RLS blocks cross-user reads;
- signed URLs expire;
- deleted account cannot retrieve assets;
- no service-role key in client bundle;
- unauthorized provider-guide admin updates blocked.

## 8. Accessibility Tests
- screen reader order;
- dynamic type;
- contrast;
- large text clipping;
- reduced motion;
- buttons have accessible labels.

## 9. Device Matrix
At minimum:
- current iPhone generation;
- older supported iPhone;
- small-screen iPhone;
- current Pixel/Android reference;
- Samsung common device class;
- lower-memory Android device.

## 10. Release Blockers
Do not ship if:
- confirmed renewal dates create incorrect reminders;
- notifications frequently fail in supported flows;
- cross-user data access is possible;
- purchase/restore is broken;
- account deletion is broken;
- screenshot extraction silently hallucinates dates/amounts without review.
