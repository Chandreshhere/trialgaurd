# API & Backend Specification

## Architecture
Recommended MVP architecture:

Mobile App
→ Supabase Auth
→ Postgres + RLS
→ Edge Functions / backend API
→ AI extraction provider
→ RevenueCat webhook sync
→ notification scheduling service where needed

## Core Backend Modules

1. Authentication
2. Trial CRUD
3. AI extraction orchestration
4. Provider metadata/cancellation guides
5. Reminder scheduling
6. Proof storage
7. Entitlement sync
8. Analytics hooks
9. Admin provider-guide maintenance

## Suggested Endpoints / Functions

### POST `/trial-extractions`
Input:
```json
{
  "source_type": "screenshot",
  "asset_id": "uuid",
  "locale": "en-US",
  "timezone": "America/New_York"
}
```

Output:
```json
{
  "extraction_id": "uuid",
  "service_name": "Adobe Creative Cloud",
  "plan_name": null,
  "renewal_date": "2026-09-14",
  "renewal_time": null,
  "amount_minor": 7999,
  "currency": "USD",
  "billing_interval": "year",
  "confidence": {
    "service": 0.96,
    "renewal_date": 0.91,
    "amount": 0.88,
    "currency": 0.99
  },
  "warnings": ["Exact billing time was not shown."]
}
```

### POST `/trials`
Creates confirmed trial.

Server validates:
- user owns data;
- required fields present;
- renewal date is plausible;
- amount >= 0 if provided;
- timezone valid.

### PATCH `/trials/:id`
Editable fields only. Recalculate reminders if critical data changes.

### POST `/trials/:id/activate`
- verifies user confirmation;
- calculates safe cancel timestamp;
- creates reminder schedule;
- returns schedule.

### POST `/trials/:id/decision`
Body:
```json
{ "decision": "cancel" }
```
or
```json
{ "decision": "keep" }
```

### POST `/trials/:id/cancelled`
Marks cancelled with optional proof metadata.

### POST `/trials/:id/proof`
Creates proof record after upload.

### GET `/providers/search?q=`
Search known providers.

### GET `/providers/:id/cancel-guide`
Returns current cancellation steps.

### GET `/me/summary`
Returns:
- active count;
- money at risk;
- money saved;
- next urgent trial.

## Row Level Security
Every user-owned table must enforce:
`user_id = auth.uid()`

No mobile client should be able to read another user's records.

## Service Role Usage
Use service-role access only in trusted server/edge execution.

## Idempotency
Activation and reminder creation should be idempotent to avoid duplicated notifications.

## Provider Guide Updates
Cancellation links can change. Store:
- guide version;
- updated date;
- active/inactive status.

Admin should be able to modify provider guidance without mobile app release.

## Background Jobs
Potential jobs:
- check stale active trials past renewal;
- reconcile failed push registrations;
- entitlement sync;
- notify user when provider cancellation guide materially changes if necessary.

## Offline Strategy
Cache active trial records locally.
Server remains source of truth for account data, but scheduled local notifications should survive intermittent connectivity where platform permits.
