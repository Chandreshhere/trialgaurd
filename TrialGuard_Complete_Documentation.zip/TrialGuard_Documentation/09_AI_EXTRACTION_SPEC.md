# AI Extraction Specification

## Goal
Convert user-provided trial confirmation content into reliable structured fields while minimizing hallucination risk.

## Supported Inputs
- screenshot;
- photo;
- pasted text;
- later: share-sheet webpage snippets.

## Required Output Schema

```json
{
  "service_name": "string|null",
  "plan_name": "string|null",
  "trial_start_date": "YYYY-MM-DD|null",
  "renewal_date": "YYYY-MM-DD|null",
  "renewal_time": "HH:mm:ss|null",
  "timezone": "IANA|string|null",
  "renewal_amount": "number|null",
  "currency": "ISO4217|null",
  "billing_interval": "week|month|quarter|year|other|unknown|null",
  "explicit_cancel_by_date": "YYYY-MM-DD|null",
  "confidence": {
    "service_name": 0.0,
    "renewal_date": 0.0,
    "renewal_amount": 0.0,
    "currency": 0.0,
    "billing_interval": 0.0
  },
  "warnings": []
}
```

## Extraction Rules

### Rule 1 — Never invent missing values
If renewal amount is not visible, return null.

### Rule 2 — Separate trial end vs billing date
If content says:
`Free until Sep 10, then billed Sep 11`
renewal date is Sep 11.

### Rule 3 — Distinguish promotional pricing
If screenshot includes:
`$0 today, then $9.99/month`
renewal amount = 9.99.

### Rule 4 — Distinguish annual equivalent text
If screenshot says:
`$8.33/month billed annually at $99.99`
renewal amount should be 99.99 and interval year if that is the actual next charge.

### Rule 5 — Multiple prices
If multiple plans/options are visible and the selected plan cannot be identified, return warning and require user selection.

### Rule 6 — Date ambiguity
`09/10/2026` is locale-sensitive. Use device locale plus nearby language/context. If still ambiguous, flag it.

### Rule 7 — Relative dates
For `7-day free trial`, calculate end only if a trustworthy trial start timestamp is known. Otherwise request user confirmation.

### Rule 8 — Exact time uncertainty
If only a date is shown, do not invent midnight/11:59 as provider billing time. Store date-only and use conservative safe buffer.

### Rule 9 — Cancellation confirmation
For proof screenshots, detect phrases such as:
- cancelled;
- subscription ends on;
- auto-renew off;
- you will not be charged;
- cancellation confirmation.

But always let user confirm.

## Confidence Thresholds
Suggested:
- >= 0.90: normal display;
- 0.70–0.89: show `Please check`;
- < 0.70: highlight and require explicit edit/confirmation.

Renewal date should always require confirmation regardless of confidence.

## Prompting Principle
Extraction model should be instructed to behave as a structured parser, not an advisor.

## Validation Layer
After AI response:
- validate currency code;
- validate date syntax;
- reject impossible dates;
- check renewal date not implausibly far in past;
- normalize money to minor units;
- strip unsupported HTML/text.

## Privacy
Do not use user screenshots for model training unless user explicitly opts in under a documented policy.

## Cost Controls
- resize/compress images before upload while preserving text readability;
- use low-cost vision-capable model where accuracy is sufficient;
- avoid repeated extraction once user confirmed;
- cache extraction result.
