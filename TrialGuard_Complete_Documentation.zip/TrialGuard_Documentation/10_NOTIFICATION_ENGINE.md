# Notification Engine Specification

## Product Principle
Notifications are not a secondary feature. They are the core mechanism of protection.

## Default Reminder Ladder
For a trial with enough time remaining:

1. 7 days before renewal
2. 3 days before
3. 24 hours before
4. 6 hours before

Optional later:
- 1 hour before safe-cancel deadline;
- custom user schedule.

## Safe-Cancel Logic

### Exact renewal timestamp known
Default safe buffer: 24 hours.

### Only renewal date known
Default safe buffer: 48 hours before assumed start of renewal date in user/provider-local context.

### Explicit provider cancellation deadline known
Use earlier of:
- provider deadline;
- conservative calculated safe deadline.

## Adaptive Schedule Examples

### Trial has 12 days remaining
Use all four reminders.

### Trial has 5 days remaining
Use:
- 3 days;
- 24h;
- 6h.

### Trial has 30 hours remaining
Use:
- 24h;
- 6h.

### Trial has 4 hours remaining
Use immediate warning and a final reminder if safe.

### Trial is already inside safe-cancel buffer
Display critical warning:
`This trial may be too close to renewal. Cancel now if you do not want to continue.`

## Notification Content Requirements
Every critical reminder should contain:
- provider name;
- amount if known;
- time remaining;
- clear action context.

## Copy Examples

### 7 days
`Adobe may charge $79.99 next week. Decide whether you still want it.`

### 3 days
`$79.99 at risk in 3 days — Adobe is still set to renew.`

### 24 hours
`Adobe may charge $79.99 tomorrow. Cancel now if you do not want it.`

### 6 hours
`Final TrialGuard reminder: Adobe's $79.99 renewal is approaching.`

## Actions
Where platform supports notification actions:
- `Cancel`
- `Keep`
- `Later`

All actions should open app into correct flow unless safe direct action is possible.

## Reminder Cancellation
Cancel future reminders immediately when trial becomes:
- cancelled;
- kept;
- archived.

## Editing Renewal Date
When critical dates change:
1. cancel existing reminders;
2. regenerate schedule;
3. schedule new reminders;
4. confirm success.

## Timezone Changes
On device timezone change:
- preserve absolute provider time if known;
- adjust display appropriately;
- re-evaluate date-only records conservatively.

## Reliability Strategy
Prefer redundant protection where platform allows:
- local scheduled notifications;
- optional server push fallback.

## Permission-Off State
App must never display `Protected` without qualification if notifications are disabled.

Recommended status:
`Tracked — notifications off`

CTA:
`Enable reminders`
