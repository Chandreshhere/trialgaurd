# Release Plan & Roadmap

## Phase 0 — Validation Before Full Build
Create:
- landing page;
- prototype/Figma flow;
- 15–20 second product demo;
- waitlist.

Validation questions:
- do users understand screenshot → protection instantly?
- will users trust notifications without bank/email access?
- is annual pricing acceptable?

## Phase 1 — Internal Alpha
Scope:
- auth;
- manual trial creation;
- active dashboard;
- local reminders;
- keep/cancel states;
- history.

Purpose:
Validate reminder engine before AI.

## Phase 2 — AI Beta
Add:
- screenshot import;
- structured extraction;
- field confidence;
- correction flow;
- source-image storage.

## Phase 3 — Cancellation Beta
Add:
- provider database;
- cancellation URL/deep links;
- instructions;
- cancellation proof;
- money saved.

## Phase 4 — Monetization Beta
Add:
- RevenueCat;
- Free/Pro limits;
- paywall;
- restore purchase;
- entitlement analytics.

## Phase 5 — Public MVP
Launch gates:
- crash-free target met;
- extraction date accuracy validated;
- notification reliability validated;
- legal/privacy pages live;
- store screenshots/metadata complete;
- support path operational.

## Post-MVP Roadmap

### V1.1
- provider logos;
- smarter provider matching;
- improved notification actions;
- better history insights.

### V1.2
- share sheet integration;
- automatic parsing of copied confirmation text;
- region-aware cancellation guide variants.

### V1.3
- optional browser extension;
- sync extension-created trials to mobile.

### V1.4
- family/shared household mode if validated.

### V2 Candidates — Only After Validation
- email forwarding address for trial confirmations;
- renewal tracking beyond trial period;
- receipt/warranty extensions;
- refund evidence workflow;
- desktop web portal.

## Explicitly Deferred
- bank connection;
- automatic cancellation with credentials;
- subscription marketplace;
- budgeting;
- financial advice.
