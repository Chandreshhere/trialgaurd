# Data Model

## General Rules
- Use UUID primary keys.
- Store timestamps in UTC with timezone metadata when source timezone matters.
- Use integer minor units for money where practical (e.g. cents) to avoid floating-point errors.
- Use ISO 4217 currency codes.

## Table: profiles

| Field | Type | Notes |
|---|---|---|
| id | uuid | same as auth user id |
| display_name | text nullable | optional |
| default_currency | char(3) | e.g. USD |
| timezone | text | IANA timezone |
| default_safe_buffer_hours | int | default 48 if date-only |
| aggressive_alerts | bool | default true |
| created_at | timestamptz | |
| updated_at | timestamptz | |

## Table: trials

| Field | Type | Notes |
|---|---|---|
| id | uuid | PK |
| user_id | uuid | FK |
| provider_id | uuid nullable | known provider |
| service_name | text | confirmed display name |
| plan_name | text nullable | |
| status | enum | see statuses |
| trial_start_at | timestamptz nullable | |
| renewal_at | timestamptz nullable | exact time if known |
| renewal_date_only | date nullable | use if source only gives date |
| source_timezone | text nullable | |
| safe_cancel_at | timestamptz | calculated |
| renewal_amount_minor | bigint nullable | cents/pence etc. |
| currency | char(3) nullable | |
| billing_interval | enum nullable | month/year/week/other |
| source_type | enum | screenshot/camera/paste/manual |
| source_asset_id | uuid nullable | |
| ai_extraction_id | uuid nullable | |
| user_confirmed | bool | must be true before active |
| notes | text nullable | |
| kept_at | timestamptz nullable | |
| cancelled_at | timestamptz nullable | |
| created_at | timestamptz | |
| updated_at | timestamptz | |

## Enum: trial_status
- draft
- active
- kept
- cancellation_in_progress
- cancelled
- renewed_or_charged
- expired
- archived

## Enum: billing_interval
- week
- month
- quarter
- year
- one_time_after_trial
- other
- unknown

## Table: reminder_schedules

| Field | Type |
|---|---|
| id | uuid |
| trial_id | uuid |
| user_id | uuid |
| remind_at | timestamptz |
| reminder_type | enum |
| status | enum |
| local_notification_id | text nullable |
| push_notification_id | text nullable |
| opened_at | timestamptz nullable |
| acted_at | timestamptz nullable |
| created_at | timestamptz |

Reminder types:
- seven_day
- three_day
- one_day
- six_hour
- custom
- snooze
- final

Status:
- scheduled
- delivered
- opened
- cancelled
- failed

## Table: source_assets

| Field | Type |
|---|---|
| id | uuid |
| user_id | uuid |
| trial_id | uuid nullable |
| asset_type | enum |
| storage_path | text |
| mime_type | text |
| created_at | timestamptz |
| deleted_at | timestamptz nullable |

Asset types:
- trial_screenshot
- camera_capture
- cancellation_proof

## Table: ai_extractions

| Field | Type |
|---|---|
| id | uuid |
| user_id | uuid |
| source_asset_id | uuid nullable |
| raw_text | text nullable |
| extracted_json | jsonb |
| provider_confidence | numeric |
| date_confidence | numeric |
| amount_confidence | numeric |
| currency_confidence | numeric |
| model_version | text |
| extraction_status | enum |
| created_at | timestamptz |

## Table: cancellation_proofs

| Field | Type |
|---|---|
| id | uuid |
| trial_id | uuid |
| user_id | uuid |
| source_asset_id | uuid |
| reference_number | text nullable |
| access_end_date | date nullable |
| extracted_confirmation | bool nullable |
| user_confirmed | bool |
| created_at | timestamptz |

## Table: providers

| Field | Type |
|---|---|
| id | uuid |
| canonical_name | text |
| domain | text nullable |
| logo_url | text nullable |
| cancellation_url | text nullable |
| apple_managed | bool |
| google_play_managed | bool |
| guide_version | int |
| active | bool |
| updated_at | timestamptz |

## Table: provider_cancel_steps

| Field | Type |
|---|---|
| id | uuid |
| provider_id | uuid |
| step_order | int |
| instruction | text |
| deep_link | text nullable |
| region | text nullable |
| active | bool |

## Table: entitlements

| Field | Type |
|---|---|
| user_id | uuid |
| plan | enum |
| source | enum |
| product_id | text nullable |
| expires_at | timestamptz nullable |
| updated_at | timestamptz |

## Computed Metrics
### Money at Risk
Sum of known renewal amounts for active trials not past renewal.

### Money Saved
Sum of renewal amounts for trials explicitly marked cancelled before renewal.

Do not count:
- unknown amounts;
- expired trials without cancellation confirmation;
- estimated multi-year future savings.
