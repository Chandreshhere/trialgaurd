# Analytics & Event Taxonomy

## Objectives
Measure:
- acquisition quality;
- activation;
- trial-protection success;
- reminder effectiveness;
- cancellation outcomes;
- monetization;
- extraction reliability.

## Core Funnel
Install
→ onboarding_started
→ onboarding_completed
→ add_trial_started
→ source_selected
→ extraction_completed
→ trial_confirmed
→ protection_activated
→ reminder_opened
→ decision_made
→ cancellation_confirmed
→ paywall_viewed
→ purchase_completed

## Event List

### Acquisition / Onboarding
- `app_first_open`
- `onboarding_started`
- `onboarding_step_viewed`
- `notification_education_viewed`
- `notification_permission_granted`
- `notification_permission_denied`
- `signup_completed`

### Trial Creation
- `add_trial_started`
- `trial_source_selected`
Properties: screenshot/camera/paste/manual
- `image_selected`
- `extraction_started`
- `extraction_succeeded`
- `extraction_failed`
- `extraction_field_corrected`
Properties: field name
- `trial_confirmed`
- `protection_activated`

### Dashboard
- `trial_card_opened`
- `add_trial_tapped`

### Notifications
- `reminder_scheduled`
- `reminder_opened`
- `reminder_action_cancel`
- `reminder_action_keep`
- `reminder_snoozed`

### Decisions
- `cancel_flow_started`
- `provider_cancel_link_opened`
- `trial_marked_cancelled`
- `trial_marked_kept`
- `cancellation_proof_added`

### Monetization
- `paywall_viewed`
- `paywall_cta_tapped`
- `purchase_started`
- `purchase_completed`
- `purchase_failed`
- `purchase_restored`

### Data & Settings
- `trial_edited`
- `trial_archived`
- `account_delete_started`
- `account_deleted`

## Important Properties
Avoid storing raw sensitive screenshot text in analytics.

Useful properties:
- country/locale;
- source method;
- days until renewal bucket;
- amount bucket;
- billing interval;
- provider known/unknown;
- AI confidence bucket;
- free/pro;
- notification permission state.

## Primary Metrics

### Activation Rate
Users protecting first trial / users completing onboarding.

### Extraction Success Rate
Successful structured extraction / extraction attempts.

### Confirmation Correction Rate
% extraction records where user edits detected date/amount.

High correction rate means model/system is unreliable.

### Reminder Action Rate
Users taking keep/cancel action after reminder.

### Prevented-Renewal Rate
Cancelled-before-renewal / resolved active trials.

### Paid Conversion
Paid users / eligible activated users.

## North-Star Candidate
**Protected Trials Resolved Before Renewal**

This is better than DAU because the product is episodic.
