# Security, Privacy & Compliance Requirements

## Security Objective
TrialGuard handles screenshots that may contain names, email addresses, prices, account fragments, and other personal information. The app must minimize collection and isolate user data.

## Data Minimization
Collect only what is needed to:
- identify the service;
- identify renewal terms;
- schedule reminders;
- support cancellation proof.

Do not request:
- bank credentials;
- service passwords;
- payment card numbers;
- full email inbox access;
- browser history.

## Authentication
Recommended:
- Apple sign-in on iOS;
- Google sign-in where appropriate;
- passwordless email/magic link.

## Authorization
Use row-level security on every user-owned table.

## Storage
Screenshots/proofs should be private objects, never public URLs.

Use time-limited signed URLs for viewing.

## Encryption
- HTTPS/TLS in transit;
- managed encryption at rest;
- secrets in server-side environment variables only.

## API Keys
Never embed privileged service keys in mobile client.

## Image Retention
Offer user control:
- keep screenshot;
- delete original after extraction;
- delete proof.

Consider default option:
`Delete source screenshot after details are confirmed`.

## AI Provider Privacy
Document:
- which data is sent to AI provider;
- retention configuration;
- whether data is used for training;
- deletion behavior.

Prefer API configuration with no-training/default enterprise privacy protections where available.

## Logging
Do not log:
- raw screenshots;
- cancellation proof contents;
- auth tokens;
- full pasted confirmation text unless needed and properly protected.

## Account Deletion
Deletion should cover:
- profile;
- trials;
- reminders;
- screenshots;
- proof images;
- extraction records where legally/operationally permitted.

## Privacy UX
Provide plain-English explanation before image upload:
`We analyze this image only to detect trial details.`

## Legal Pages Required Before Public Launch
- Privacy Policy
- Terms of Use
- Subscription/Billing Terms
- AI Processing Disclosure
- Support Contact

## Disclaimers
TrialGuard should not claim:
- guaranteed cancellation;
- guaranteed refund;
- guaranteed notification delivery;
- provider affiliation where none exists.

Suggested:
`TrialGuard is an independent reminder and organization tool. Service providers control their own billing and cancellation terms.`

## Children
Unless explicitly designed otherwise, set product age rating/terms for general adult consumer use and avoid collecting children's data.

## Regional Privacy
Architecture should be capable of supporting relevant rights such as:
- access;
- correction;
- deletion;
- export where required;
- consent/opt-out mechanisms depending on applicable law.

Obtain jurisdiction-specific legal review before launch at scale.
