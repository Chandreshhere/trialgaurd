# MVP Acceptance Criteria

## A. Onboarding
- [ ] New user can understand product purpose without external explanation.
- [ ] Notification permission is preceded by explanatory screen.
- [ ] User can complete signup/sign-in.

## B. Add Trial
- [ ] User can add trial manually.
- [ ] User can add via screenshot.
- [ ] User can add via camera/photo if supported.
- [ ] User can paste confirmation text.
- [ ] AI output is editable.
- [ ] App never activates protection until user confirms renewal date.

## C. Trial Protection
- [ ] System calculates safe-cancel date.
- [ ] Reminder schedule is visible.
- [ ] Past reminder times are excluded.
- [ ] Activating twice does not create duplicates.

## D. Dashboard
- [ ] Active trials sorted by urgency.
- [ ] Money at Risk is mathematically correct for known amounts.
- [ ] Unknown amounts do not break totals.

## E. Reminders
- [ ] Reminder appears at configured time on supported physical device.
- [ ] Notification tap opens correct trial.
- [ ] Cancelled/kept trial stops future reminders.
- [ ] Permission-off state is clearly visible.

## F. Cancel/Keep
- [ ] User can mark Keep.
- [ ] User can enter Cancel flow.
- [ ] Known provider guide opens correct destination.
- [ ] User can mark cancellation complete.
- [ ] User can optionally store proof.

## G. Money Saved
- [ ] Only confirmed cancelled-before-renewal trials count.
- [ ] Amount uses correct currency.
- [ ] App does not project speculative future savings.

## H. History
- [ ] Cancelled, kept, and archived records are retrievable.
- [ ] History reflects correct decision timestamps.

## I. Payments
- [ ] Paywall displays correct product.
- [ ] Purchase activates Pro.
- [ ] Restore purchase works.
- [ ] Entitlement expiry behaves correctly.
- [ ] Existing protected reminders are not intentionally disabled merely because plan expires.

## J. Security
- [ ] User A cannot query User B trials/assets.
- [ ] Screenshots are private.
- [ ] No privileged keys ship in client bundle.
- [ ] Account deletion removes user-accessible data per policy.

## K. Reliability
- [ ] No known P0/P1 bug in protect → remind → decide → cancel path.
- [ ] Crash-free session target met during beta.
- [ ] Date/time edge cases tested.

## L. Store Readiness
- [ ] Privacy policy live.
- [ ] Terms live.
- [ ] Support contact works.
- [ ] Store subscription disclosure complete.
- [ ] Permission descriptions are accurate.
- [ ] App screenshots and metadata prepared.
